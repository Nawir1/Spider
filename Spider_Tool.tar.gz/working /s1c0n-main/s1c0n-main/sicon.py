## 1.1: importing dependencies
from turtle import color


try:
	from os import path, system, getcwd
	import os.path
	import subprocess
	import nmap
	import json
	import sys
	import time
	import logging
except ImportError as error:
	print("\n\t   [!] Error on import", error)



logging.basicConfig(filename="result.txt",filemode="w",format=" %(asctime)s : %(message)s",level=logging.INFO)
## 1.2: defining classes & functions:
class Colors:
	RESET     = "\33[0m"  # Ansi color codes used to color the terminal
	BOLD      = "\33[1m"
	RED       = "\33[31m"
	GREEN     = "\33[32m"
	YELLOW    = "\33[33m"

## 1.4 checking dependecies tools

def check(tool):
  if os.path.exists("/usr/bin/" + tool) == True:
	  print(Colors.GREEN + Colors.BOLD + "[*] " + tool +  " exist" + Colors.RESET)
	  time.sleep(0.2)
	  pass

  elif os.path.exists("/usr/bin" + tool) == False:
	  # checking user privileges
	  user = os.getuid() #the current process’s real user
	  
	  if user == 0: #if root 
		  pass

	  else:
		  print(Colors.RED + Colors.BOLD + "[!] " + tool + " is missing, Please run me with sudo to install " + tool + Colors.RESET)
		  exit()
	  # installing missing requirements
	  print(Colors.RED + Colors.BOLD + "[!] " + tool + " missing" + Colors.RESET)
	  print(Colors.RED + Colors.BOLD + "[!] installing " + tool + Colors.RESET)
	  time.sleep(0.2)
	  system("apt install "+ tool + " -y")

# requirements
list_tool = ['nmap','wafw00f','whatweb','wapiti','httprobe']
for tool in list_tool:
  check(tool)
  pass

def break_and_help():
	print("\n\t   [?] Usage example: sicon -u target.com")
	exit()

def remove_list_files(extension):
	system("rm -rf .list*.%s" % extension)



## 1.4: preparing everything
saving_path = getcwd() + "/"  #Print current working directory
port_scan = nmap.PortScanner()  # use the nmap

## 1.5: "welcome" screen
#system("clear")
print(Colors.GREEN + Colors.BOLD + """
                                                                
                                                              
							
				   ▄▀▀▀▀▄  ▄▀▀▄▀▀▀▄  ▄▀▀█▀▄    ▄▀▀█▄▄   ▄▀▀█▄▄▄▄  ▄▀▀▄▀▀▀▄ 
				  █ █   ▐ █   █   █ █   █  █  █ ▄▀   █ ▐  ▄▀   ▐ █   █   █ 
				     ▀▄   ▐  █▀▀▀▀  ▐   █  ▐  ▐ █    █   █▄▄▄▄▄  ▐  █▀▀█▀  
				  ▀▄   █     █          █       █    █   █    ▌   ▄▀    █  
				   █▀▀▀    ▄▀        ▄▀▀▀▀▀▄   ▄▀▄▄▄▄▀  ▄▀▄▄▄▄   █     █   
				   ▐      █         █       █ █     ▐   █    ▐   ▐     ▐   
					  ▐         ▐       ▐ ▐         ▐                  
					     
					 
                
                    Simple Recon tool
                Coded by """ + Colors.RESET + Colors.RED + Colors.BOLD + """Team 2""" + Colors.RESET + Colors.GREEN + Colors.BOLD + """
		   Thanks to:""" + Colors.RED + Colors.BOLD + """ Dr.Hussin""" +
Colors.RESET)


## 1.6: getting started
#sys.argv is a list in Python that contains all the command-line arguments passed to the scrip
command_arguments = sys.argv[1:] # python3 sicon.py -u scanme.nmap.org -->  -u scanme.nmap.org 

if (len(command_arguments) > 0):
	flag = command_arguments[0].upper()

	if flag == "-U" or flag == "--URL":
		URL_TARGET = command_arguments[1]

	else:
		break_and_help()

else:
	break_and_help()

 

## 2.0: Starting recon phase:
print(Colors.BOLD + Colors.GREEN + "\n\t[*] Starting recon on %s:" % URL_TARGET + Colors.RESET)

# ping the website:

command = ["ping","-c", "3", URL_TARGET]           #ping commnad
result = subprocess.call(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)  

###########
if result==0:
  print(Colors.BOLD + Colors.GREEN + "\n\t[*] Target is alive %s:" % URL_TARGET + Colors.RESET)

else:
    print(Colors.BOLD + Colors.RED + "\n\t[*] Target is not alive %s:" % URL_TARGET + Colors.RESET) 

 






## 2.1: Detect WAF using wafw00f:
# convert to domain using httprobe: It takes a list of domains and probe for working http and https servers in this case we care about the https

get_host   = subprocess.check_output(("echo %s | httprobe -prefer-https" % URL_TARGET), shell=True, text=True) # for example :scanme.nmap.org -->http//:scanme.nmap.org
detect_waf = subprocess.check_output(("wafw00f %s > /dev/null" % get_host), shell=True, text=True) #Use the wafw00f tool to find whether firewall security is behind a domain or not
logging.info("------------------------------------------------------------SUMMARY------------------------------------------------------------")

logging.info("\n\n\n\t\t\t****************************** wafw00f scan: ******************************")

if ("is behind" in detect_waf):
	## has some WAF
	processed_string = detect_waf[detect_waf.find("is behind"):]
	pre_parser  = processed_string.find("\x1b[1;96m") # process to get valuable results only
	post_parser = processed_string.find("\x1b[0m")
	which_waf   = processed_string[pre_parser:post_parser] # don't include color codes

	print(Colors.BOLD + Colors.GREEN + "\n\t  [+] WAF: DETECTED [ %s ]" % which_waf + Colors.RESET)
	logging.info(f"[+] WAF: DETECTED on {get_host}")

elif ("No WAF detected" in detect_waf):
	print(Colors.BOLD + Colors.YELLOW + "\n\t  [+] WAF: NOT DETECTED" + Colors.RESET)
	logging.info(f"[+] WAF: NOT DETECTED on {get_host}")

else:
	print(Colors.BOLD + Colors.RED  + "\n\t  [!] FAIL TO DETECT WAF" + Colors.RESET)
	logging.info(f"[+] FAIL TO DETECT WAF")
	

#try
### 2.2: Scanning ports using nmap
# run NMAP and filter results using GREP 

system("nmap %s -o .list_NMAP.txt > /dev/null" % URL_TARGET)
system("cat .list_NMAP.txt | grep open > .list_PORTS.txt")

# open file we just created
with open(".list_PORTS.txt", encoding="utf-8") as file:
 ports_list = file.read().splitlines()

# remove files we just created
remove_list_files("txt")

print(Colors.BOLD + Colors.GREEN + "\n\t  [+] OPENED PORTS: %s" % len(ports_list) + Colors.RESET)

logging.info("\n\n\n\t\t\t******************************nmap open port scan:******************************")
for p in ports_list:
  print(Colors.RESET + "\t    " + Colors.GREEN + "-> " + Colors.RESET + Colors.BOLD + p)
  
  
  logging.info(f"-> {p} ")
  






print("")

print("")
#except Exception as ex3:
 #print("Error in NMAP scanning",ex3)
 
try:
 
 logging.info("\n\n\n\t\t\t ******************************whatweb scan:****************************** ")
 web = subprocess.check_output(("whatweb %s " % URL_TARGET),shell=True, text=True) #[---,---,--,]

 new=web.split(",")
 for i in new:
    print(Colors.BOLD + Colors.GREEN +"\t"+i+ Colors.RESET)
 #logging.info(f"{web}")
     
 print("")

 print("")
except Exception as ex4:
 print("somthing went wrong!"+ex4)
 
try:


 logging.info("\n\n\n\t\t\t******************************wapiti scan:******************************")	
 wa= subprocess.check_output(("wapiti -u %s " % get_host), shell=True, text=True)
 new2=wa.split("[*]")


 for i in new2[1:]:
   print(Colors.RESET + "\t    " + Colors.GREEN + "[*]" + Colors.RESET + Colors.BOLD + i)
   logging.info(f"\t [*] \t {i} ")
   
    
except Exception as ex5:
 print("somthing went wrong!"+ex5)
 
 





